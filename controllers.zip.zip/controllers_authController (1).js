const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { findUserByEmail, updatePassword } = require('../models/userModel');
const generateToken = require('../utils/generateToken');
const sendEmail = require('../utils/sendEmail');
require('dotenv').config();

// Enviar enlace de recuperación
const forgotPassword = async (req, res) => {
  const { email } = req.body;

  try {
    const user = await findUserByEmail(email);
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });

    const token = generateToken(email);
    const link = `http://localhost:${process.env.PORT}/api/v1/auth/reset-password/${token}`;

    await sendEmail(email, 'Recuperación de contraseña', `Haz clic en el siguiente enlace para restablecer tu contraseña:\n${link}`);

    res.json({ message: 'Se ha enviado un enlace de recuperación a tu correo electrónico' });
  } catch (error) {
    res.status(500).json({ message: 'Error interno del servidor', error: error.message });
  }
};

// Restablecer la contraseña
const resetPassword = async (req, res) => {
  const { token } = req.params;
  const { newPassword } = req.body;

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const email = decoded.email;

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await updatePassword(email, hashedPassword);

    res.json({ message: 'Contraseña actualizada exitosamente' });
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      res.status(400).json({ message: 'El enlace ha expirado. Solicita uno nuevo.' });
    } else {
      res.status(400).json({ message: 'Token inválido o error al actualizar la contraseña' });
    }
  }
};

module.exports = { forgotPassword, resetPassword };
