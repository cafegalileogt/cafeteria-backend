const express = require('express');
const app = express();
const dotenv = require('dotenv');
const authRoutes = require('./routes/authRouters');

dotenv.config();
app.use(express.json());

// Rutas
app.use('/api/v1/auth', authRoutes);

// Ruta base
app.get('/', (req, res) => {
  res.send('☕ Servidor backend Cafetería funcionando correctamente');
});

// Puerto
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor backend Cafetería escuchando en http://localhost:${PORT}`);
});

git init
git add .
git commit -m "Estructura inicial del backend de Cafetería"
