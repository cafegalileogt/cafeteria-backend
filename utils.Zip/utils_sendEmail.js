const nodemailer = require('nodemailer');

const sendEmail = async (to, subject, text) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });

  const mailOptions = {
    from: '"Cafetería App" <no-reply@cafeteria.com>',
    to,
    subject,
    text
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`📩 Correo enviado a ${to}`);
  } catch (err) {
    console.error('❌ Error enviando correo:', err.message);
  }
};

module.exports = sendEmail;
